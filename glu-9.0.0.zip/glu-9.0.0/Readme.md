                                                                            Griggorii@gmail.com
                                                             
                                                                                           MIT

Удаление лишних фаилов отвечающик за графику модуль glu вообщем ремонт графического стека и 
его обслуживание для x86_64-linux-gnu ну и соответственно если у вас i386 то заменяете в configure
Ремонт важен потому что бы не было проседании fps и этот модуль если дублируется то графика тормо
зит по этому таким образом модуль сначала удаляется и потом ставиться снова. И затем можно запустить
бенчмарк который отвечет этому фаилу что бы убедиться что графика не тормозит как ранее.

Устанавливаем libglu1-mesa-dev

make -j16

sudo make install

sudo make uninstall

sudo rm -rf /include

make clean

rm -rf ./libtool ./config.status ./config.log ./Makefile

./configure --prefix=/usr --includedir=/usr/include --mandir=/usr/share/man --infodir=/usr/share/info --localstatedir=/var --libdir=/usr/lib/x86_64-linux-gnu --libexecdir=/usr/lib/x86_64-linux-gn

make -j16

sudo make install

Помочь деньгами ремонтировать linux под систему можно сюда https://money.yandex.ru/to/410014999913799 




